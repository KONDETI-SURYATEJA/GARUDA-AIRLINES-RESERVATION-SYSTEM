package com.garuda.UserDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
